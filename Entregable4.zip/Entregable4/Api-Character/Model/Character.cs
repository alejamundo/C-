namespace ServicioAPI.Model;

public class Character{
   
    public Locacion  location{get;set;}
    public string  gender{get;set;}
    public string  image{get;set;}
    public int id { get; set; }
    public string name {get;set;}
    public string status{get;set;}
    public string  species{get;set;}
     public class Locacion
    {
        public string name { get; set; }
    }
}