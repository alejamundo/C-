namespace PasrtidoBascket;


//interfaz donde definimos los atributos obligatoros
public interface InterfazJugador
{
    string Nombre { get; }
    string Posicion { get; }
    int Rendimiento { get; }
}