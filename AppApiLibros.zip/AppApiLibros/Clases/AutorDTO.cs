// nombre de espacio de espacio 
namespace AppApiLibros;

// DTO para definir los atributos de un autor
class AutorDTO
{
    public int id { get; set; }
    public string nombre { get; set; }
    public string nacionalidad { get; set; }
}