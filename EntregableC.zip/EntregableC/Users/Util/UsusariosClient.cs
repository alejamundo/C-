using ServicioAPI.Model;
using System.Text.Json;

namespace ServicioAPI.Util
{

    public class UsusariosClient{
        public HttpClient Client { get; set; }

        public UsusariosClient(HttpClient client)
        {
            this.Client = client;
        }
        public async Task<Usuarios>? GetUsuarios(string id)
        {
            var response = await this.Client.GetAsync($"https://jsonplaceholder.typicode.com/users/{id}");

            var content = await response.Content.ReadAsStringAsync();

            return JsonSerializer.Deserialize<Usuarios>(content);
        }


         public async Task<List<Detalle>> GetDetalles(string id)
        {
            try
            {
                var response = await this.Client.GetAsync($"https://jsonplaceholder.typicode.com/albums?userId={id}");
                var content = await response.Content.ReadAsStringAsync();

                List<Detalle> detalle = new List<Detalle>();

                using (JsonDocument document = JsonDocument.Parse(content))
                {
                    JsonElement root = document.RootElement;
                    if (root.ValueKind == JsonValueKind.Array)
                    {
                        foreach (JsonElement element in root.EnumerateArray())
                        {
                            Detalle post = new Detalle
                            {
                                userId = element.GetProperty("userId").GetInt32(),
                                id = element.GetProperty("id").GetInt32(),
                                title = element.GetProperty("title").GetString(),
                            };

                            detalle.Add(post);
                        }
                    }
                }

                return detalle;
            }
            catch (Exception ex)
            {
                // Manejar el error o imprimir más detalles sobre el error
                Console.WriteLine(ex);
            }
            return null;
        }
    }
}