namespace ServicioAPI.Model;

 public class Detalle
    {
        public int userId { get; set; }
        public int id { get; set; }
        public string title{ get; set; }
        
    }