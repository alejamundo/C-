namespace ConsumeAPI.Model
{
    public class Sprite
    {
        public string? front_default { get; set; }
    }
}