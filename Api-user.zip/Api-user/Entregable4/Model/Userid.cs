namespace ServicioAPI.Model;

 public class Userid
    {
        public int userId { get; set; }
        public int id { get; set; }
        public string title{ get; set; }
        
    }