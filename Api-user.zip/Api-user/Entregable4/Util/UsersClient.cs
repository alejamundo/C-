using ServicioAPI.Model;
using System.Text.Json;

namespace ServicioAPI.Util
{

    public class UsersClient{
        public HttpClient Client { get; set; }

        public UsersClient(HttpClient client)
        {
            this.Client = client;
        }
        public async Task<Users>? Getusers(string id)
        {
            var response = await this.Client.GetAsync($"https://jsonplaceholder.typicode.com/users/{id}");

            var content = await response.Content.ReadAsStringAsync();

            return JsonSerializer.Deserialize<Users>(content);
        }
        public async Task<List<Userid>> GetUserid(string id)
        {
            try
            {
                var response = await this.Client.GetAsync($"https://jsonplaceholder.typicode.com/albums?userId={id}");
                var content = await response.Content.ReadAsStringAsync();

                List<Userid> users = new List<Userid>();

                using (JsonDocument document = JsonDocument.Parse(content))
                {
                    JsonElement root = document.RootElement;
                    if (root.ValueKind == JsonValueKind.Array)
                    {
                        foreach (JsonElement element in root.EnumerateArray())
                        {
                            Userid post = new Userid
                            {
                                userId = element.GetProperty("userId").GetInt32(),
                                id = element.GetProperty("id").GetInt32(),
                                title = element.GetProperty("title").GetString(),
                            };

                            users.Add(post);
                        }
                    }
                }

                return users;
            }
            catch (Exception ex)
            {
                // Manejar el error o imprimir más detalles sobre el error
                Console.WriteLine(ex);
            }
            return null;
        }

    }    
}